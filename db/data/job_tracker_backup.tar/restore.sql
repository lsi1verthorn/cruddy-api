--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER ROLE postgres IN DATABASE postgres SET search_path TO 'job_tracker', 'public';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: job_tracker; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA job_tracker;


ALTER SCHEMA job_tracker OWNER TO postgres;

--
-- Name: SCHEMA job_tracker; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA job_tracker IS 'Keep track of job applications for job search';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: application; Type: TABLE; Schema: job_tracker; Owner: postgres
--

CREATE TABLE job_tracker.application (
    id integer NOT NULL,
    application_date date NOT NULL,
    referral boolean DEFAULT false NOT NULL,
    referred_by text DEFAULT ''::text,
    contacted boolean DEFAULT false NOT NULL,
    status text NOT NULL,
    rejection_date date,
    comments text,
    cover_letter text,
    company_id integer NOT NULL,
    job_id integer NOT NULL,
    contact_id integer,
    CONSTRAINT status_chk CHECK ((status = ANY (ARRAY['Applied'::text, 'Callback'::text, 'CodingAssignment'::text, 'Ghosted'::text, 'Interview 1'::text, 'Interview 2'::text, 'Interview 3'::text, 'Rejected'::text])))
);


ALTER TABLE job_tracker.application OWNER TO postgres;

--
-- Name: TABLE application; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON TABLE job_tracker.application IS 'Information pertaining to the application';


--
-- Name: COLUMN application.id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.id IS 'Unique ID';


--
-- Name: COLUMN application.application_date; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.application_date IS 'Date application submitted';


--
-- Name: COLUMN application.referral; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.referral IS 'Did someone refer me?';


--
-- Name: COLUMN application.referred_by; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.referred_by IS 'Name of contact';


--
-- Name: COLUMN application.contacted; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.contacted IS 'Did i receive a call back?';


--
-- Name: COLUMN application.status; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.status IS 'Status of the application';


--
-- Name: COLUMN application.rejection_date; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.rejection_date IS 'Date if the application is rejected or if the interview process did not progress';


--
-- Name: COLUMN application.comments; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.comments IS 'Any additional comments that apply';


--
-- Name: COLUMN application.cover_letter; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.cover_letter IS 'Text of the cover letter or maybe an upload link';


--
-- Name: COLUMN application.company_id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.company_id IS 'ID of the company that has the job listing';


--
-- Name: COLUMN application.job_id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.job_id IS 'ID of the job being applied for';


--
-- Name: COLUMN application.contact_id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.application.contact_id IS 'ID of the contact person, if available';


--
-- Name: CONSTRAINT status_chk ON application; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT status_chk ON job_tracker.application IS 'Make sure that the status field can only be of certain types';


--
-- Name: Application_ApplicationId_seq; Type: SEQUENCE; Schema: job_tracker; Owner: postgres
--

ALTER TABLE job_tracker.application ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME job_tracker."Application_ApplicationId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: company; Type: TABLE; Schema: job_tracker; Owner: postgres
--

CREATE TABLE job_tracker.company (
    id integer NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    website text DEFAULT ''::text,
    CONSTRAINT website_chk CHECK ((website ~* '^(http|https)://[a-zA-Z0-9. -]+\.[a-zA-Z]{2,}$'::text))
);


ALTER TABLE job_tracker.company OWNER TO postgres;

--
-- Name: TABLE company; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON TABLE job_tracker.company IS 'Information about the company with the job opening';


--
-- Name: COLUMN company.id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.company.id IS 'Unique ID of the company';


--
-- Name: COLUMN company.name; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.company.name IS 'Company name';


--
-- Name: COLUMN company.website; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.company.website IS 'Website url if available';


--
-- Name: CONSTRAINT website_chk ON company; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT website_chk ON job_tracker.company IS 'Validate url';


--
-- Name: Company_CompanyId_seq; Type: SEQUENCE; Schema: job_tracker; Owner: postgres
--

ALTER TABLE job_tracker.company ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME job_tracker."Company_CompanyId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: contact; Type: TABLE; Schema: job_tracker; Owner: postgres
--

CREATE TABLE job_tracker.contact (
    id integer NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    email text,
    country_code text,
    phone numeric(10,0),
    CONSTRAINT email_chk CHECK ((email ~* '^[^@]+@[^@]+\.[^@]+$'::text))
);


ALTER TABLE job_tracker.contact OWNER TO postgres;

--
-- Name: TABLE contact; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON TABLE job_tracker.contact IS 'Company contact information - may be an HR recruiter for the company or an independent recruiter';


--
-- Name: COLUMN contact.id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.contact.id IS 'Unique ID';


--
-- Name: COLUMN contact.name; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.contact.name IS 'Contact name';


--
-- Name: COLUMN contact.email; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.contact.email IS 'Contact''s email, if available';


--
-- Name: COLUMN contact.country_code; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.contact.country_code IS 'In case of an international number';


--
-- Name: COLUMN contact.phone; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.contact.phone IS 'Contact phone number, if available';


--
-- Name: CONSTRAINT email_chk ON contact; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT email_chk ON job_tracker.contact IS 'Simple email validation';


--
-- Name: Contact_ContactId_seq; Type: SEQUENCE; Schema: job_tracker; Owner: postgres
--

ALTER TABLE job_tracker.contact ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME job_tracker."Contact_ContactId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: job; Type: TABLE; Schema: job_tracker; Owner: postgres
--

CREATE TABLE job_tracker.job (
    id integer NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text,
    remote boolean DEFAULT true NOT NULL,
    salary_range text DEFAULT '???'::text,
    comments text DEFAULT ''::text,
    company_id integer
);


ALTER TABLE job_tracker.job OWNER TO postgres;

--
-- Name: TABLE job; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON TABLE job_tracker.job IS 'Advertised job';


--
-- Name: COLUMN job.id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.id IS 'Unique ID';


--
-- Name: COLUMN job.title; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.title IS 'Position title';


--
-- Name: COLUMN job.description; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.description IS 'A more complete description of the job and its requirements';


--
-- Name: COLUMN job.remote; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.remote IS 'Location requirement';


--
-- Name: COLUMN job.salary_range; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.salary_range IS 'Salary range if provided in posting';


--
-- Name: COLUMN job.comments; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.comments IS 'Anything additional that might be relevant';


--
-- Name: COLUMN job.company_id; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON COLUMN job_tracker.job.company_id IS 'Company that is offering the job';


--
-- Name: Job_JobId_seq; Type: SEQUENCE; Schema: job_tracker; Owner: postgres
--

ALTER TABLE job_tracker.job ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME job_tracker."Job_JobId_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: application; Type: TABLE DATA; Schema: job_tracker; Owner: postgres
--

COPY job_tracker.application (id, application_date, referral, referred_by, contacted, status, rejection_date, comments, cover_letter, company_id, job_id, contact_id) FROM stdin;
\.
COPY job_tracker.application (id, application_date, referral, referred_by, contacted, status, rejection_date, comments, cover_letter, company_id, job_id, contact_id) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: company; Type: TABLE DATA; Schema: job_tracker; Owner: postgres
--

COPY job_tracker.company (id, name, website) FROM stdin;
\.
COPY job_tracker.company (id, name, website) FROM '$$PATH$$/3650.dat';

--
-- Data for Name: contact; Type: TABLE DATA; Schema: job_tracker; Owner: postgres
--

COPY job_tracker.contact (id, name, email, country_code, phone) FROM stdin;
\.
COPY job_tracker.contact (id, name, email, country_code, phone) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: job; Type: TABLE DATA; Schema: job_tracker; Owner: postgres
--

COPY job_tracker.job (id, title, description, remote, salary_range, comments, company_id) FROM stdin;
\.
COPY job_tracker.job (id, title, description, remote, salary_range, comments, company_id) FROM '$$PATH$$/3652.dat';

--
-- Name: Application_ApplicationId_seq; Type: SEQUENCE SET; Schema: job_tracker; Owner: postgres
--

SELECT pg_catalog.setval('job_tracker."Application_ApplicationId_seq"', 2, true);


--
-- Name: Company_CompanyId_seq; Type: SEQUENCE SET; Schema: job_tracker; Owner: postgres
--

SELECT pg_catalog.setval('job_tracker."Company_CompanyId_seq"', 8, true);


--
-- Name: Contact_ContactId_seq; Type: SEQUENCE SET; Schema: job_tracker; Owner: postgres
--

SELECT pg_catalog.setval('job_tracker."Contact_ContactId_seq"', 8, true);


--
-- Name: Job_JobId_seq; Type: SEQUENCE SET; Schema: job_tracker; Owner: postgres
--

SELECT pg_catalog.setval('job_tracker."Job_JobId_seq"', 2, true);


--
-- Name: application Application_pkey; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.application
    ADD CONSTRAINT "Application_pkey" PRIMARY KEY (id);


--
-- Name: company Company_pkey; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.company
    ADD CONSTRAINT "Company_pkey" PRIMARY KEY (id);


--
-- Name: contact Contact_pkey; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.contact
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: job Job_pkey; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.job
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: application application_uniq_id; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.application
    ADD CONSTRAINT application_uniq_id UNIQUE (id);


--
-- Name: CONSTRAINT application_uniq_id ON application; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT application_uniq_id ON job_tracker.application IS 'Unique application id';


--
-- Name: company company_uniq_id; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.company
    ADD CONSTRAINT company_uniq_id UNIQUE (id);


--
-- Name: CONSTRAINT company_uniq_id ON company; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT company_uniq_id ON job_tracker.company IS 'Company id is unique';


--
-- Name: contact contact_uniq_id; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.contact
    ADD CONSTRAINT contact_uniq_id UNIQUE (id) INCLUDE (id);


--
-- Name: CONSTRAINT contact_uniq_id ON contact; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT contact_uniq_id ON job_tracker.contact IS 'Unique contact';


--
-- Name: job job_uniq_id; Type: CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.job
    ADD CONSTRAINT job_uniq_id UNIQUE (id) INCLUDE (id);


--
-- Name: CONSTRAINT job_uniq_id ON job; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT job_uniq_id ON job_tracker.job IS 'Unique job id';


--
-- Name: fki_company-id; Type: INDEX; Schema: job_tracker; Owner: postgres
--

CREATE INDEX "fki_company-id" ON job_tracker.application USING btree (company_id);


--
-- Name: fki_company_id; Type: INDEX; Schema: job_tracker; Owner: postgres
--

CREATE INDEX fki_company_id ON job_tracker.job USING btree (company_id);


--
-- Name: fki_contact-id; Type: INDEX; Schema: job_tracker; Owner: postgres
--

CREATE INDEX "fki_contact-id" ON job_tracker.application USING btree (contact_id);


--
-- Name: fki_contact_id; Type: INDEX; Schema: job_tracker; Owner: postgres
--

CREATE INDEX fki_contact_id ON job_tracker.application USING btree (id);


--
-- Name: fki_job-id; Type: INDEX; Schema: job_tracker; Owner: postgres
--

CREATE INDEX "fki_job-id" ON job_tracker.application USING btree (job_id);


--
-- Name: fki_job_id; Type: INDEX; Schema: job_tracker; Owner: postgres
--

CREATE INDEX fki_job_id ON job_tracker.application USING btree (id);


--
-- Name: job company_id; Type: FK CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.job
    ADD CONSTRAINT company_id FOREIGN KEY (company_id) REFERENCES job_tracker.company(id);


--
-- Name: CONSTRAINT company_id ON job; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT company_id ON job_tracker.job IS 'Company id key';


--
-- Name: application company_id; Type: FK CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.application
    ADD CONSTRAINT company_id FOREIGN KEY (company_id) REFERENCES job_tracker.company(id);


--
-- Name: CONSTRAINT company_id ON application; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT company_id ON job_tracker.application IS 'Unique ID of the company';


--
-- Name: application contact_id; Type: FK CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.application
    ADD CONSTRAINT contact_id FOREIGN KEY (contact_id) REFERENCES job_tracker.contact(id);


--
-- Name: CONSTRAINT contact_id ON application; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT contact_id ON job_tracker.application IS 'ID for a contact person, if available';


--
-- Name: application job_id; Type: FK CONSTRAINT; Schema: job_tracker; Owner: postgres
--

ALTER TABLE ONLY job_tracker.application
    ADD CONSTRAINT job_id FOREIGN KEY (job_id) REFERENCES job_tracker.job(id);


--
-- Name: CONSTRAINT job_id ON application; Type: COMMENT; Schema: job_tracker; Owner: postgres
--

COMMENT ON CONSTRAINT job_id ON job_tracker.application IS 'ID of the job being offered';


--
-- PostgreSQL database dump complete
--

